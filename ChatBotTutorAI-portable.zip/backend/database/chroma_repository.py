"""ChromaDB persistence adapter for chats and messages."""

from datetime import datetime
from pathlib import Path
from typing import Any

import chromadb
from chromadb.api.models.Collection import Collection

from backend.models.chat import ChatSummary, Message
from backend.utils.time import parse_timestamp


class ChatNotFoundError(LookupError):
    """Raised when a requested chat does not exist."""


class ChromaChatRepository:
    """Persist chat metadata and ordered messages in separate collections.

    Keeping storage behind this adapter allows later memory implementations to
    add semantic collections without coupling them to HTTP handlers.
    """

    def __init__(self, persistence_path: Path) -> None:
        persistence_path.mkdir(parents=True, exist_ok=True)
        self._client = chromadb.PersistentClient(path=str(persistence_path))
        self._chats: Collection = self._client.get_or_create_collection(
            name="chats",
            embedding_function=None,
            metadata={"description": "ChatbotTutorAI conversation metadata"},
        )
        self._messages: Collection = self._client.get_or_create_collection(
            name="messages",
            embedding_function=None,
            metadata={"description": "ChatbotTutorAI ordered chat messages"},
        )

    def save_chat(self, chat: ChatSummary) -> ChatSummary:
        metadata = {
            "chat_id": chat.id,
            "title": chat.title,
            "session_id": chat.session_id,
            "created_at": chat.created_at.isoformat(),
            "updated_at": chat.updated_at.isoformat(),
        }
        self._chats.upsert(
            ids=[chat.id],
            documents=[chat.title],
            # Phase 1 performs no semantic search. A fixed vector keeps ChromaDB
            # in storage-only mode without loading its default ONNX embedder.
            embeddings=[[0.0]],
            metadatas=[metadata],
        )
        return chat

    def list_chats(self) -> list[ChatSummary]:
        result = self._chats.get(include=["metadatas"])
        chats = [
            self._chat_from_metadata(metadata)
            for metadata in result.get("metadatas") or []
            if metadata is not None
        ]
        return sorted(chats, key=lambda item: item.updated_at, reverse=True)

    def get_chat(self, chat_id: str) -> ChatSummary:
        result = self._chats.get(ids=[chat_id], include=["metadatas"])
        metadata_items = result.get("metadatas") or []
        if not metadata_items or metadata_items[0] is None:
            raise ChatNotFoundError(chat_id)
        return self._chat_from_metadata(metadata_items[0])

    def save_message(self, message: Message) -> Message:
        metadata = {
            "chat_id": message.chat_id,
            "message_id": message.id,
            "role": message.role,
            "timestamp": message.timestamp.isoformat(),
            "session_id": message.session_id,
        }
        self._messages.add(
            ids=[message.id],
            documents=[message.content],
            embeddings=[[0.0]],
            metadatas=[metadata],
        )
        return message

    def list_messages(self, chat_id: str) -> list[Message]:
        result = self._messages.get(
            where={"chat_id": chat_id},
            include=["documents", "metadatas"],
        )
        documents = result.get("documents") or []
        metadatas = result.get("metadatas") or []
        messages = [
            self._message_from_record(document, metadata)
            for document, metadata in zip(documents, metadatas, strict=True)
            if metadata is not None
        ]
        return sorted(messages, key=lambda item: item.timestamp)

    @staticmethod
    def _chat_from_metadata(metadata: dict[str, Any]) -> ChatSummary:
        return ChatSummary(
            id=str(metadata["chat_id"]),
            title=str(metadata["title"]),
            session_id=str(metadata["session_id"]),
            created_at=parse_timestamp(str(metadata["created_at"])),
            updated_at=parse_timestamp(str(metadata["updated_at"])),
        )

    @staticmethod
    def _message_from_record(
        document: str,
        metadata: dict[str, Any],
    ) -> Message:
        return Message(
            id=str(metadata["message_id"]),
            chat_id=str(metadata["chat_id"]),
            role=str(metadata["role"]),
            content=document,
            timestamp=parse_timestamp(str(metadata["timestamp"])),
            session_id=str(metadata["session_id"]),
        )
