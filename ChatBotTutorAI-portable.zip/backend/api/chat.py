"""Chat lifecycle and messaging endpoints."""

from typing import Annotated

from fastapi import APIRouter, Depends, status

from backend.api.dependencies import get_chat_service
from backend.models.chat import (
    ChatCreateRequest,
    ChatDetail,
    ChatMessageRequest,
    ChatMessageResponse,
    ChatSummary,
)
from backend.services.chat_service import ChatService


router = APIRouter(prefix="/chat", tags=["chat"])
ChatServiceDependency = Annotated[ChatService, Depends(get_chat_service)]


@router.post(
    "/create",
    response_model=ChatSummary,
    status_code=status.HTTP_201_CREATED,
)
def create_chat(
    payload: ChatCreateRequest,
    service: ChatServiceDependency,
) -> ChatSummary:
    """Create an empty conversation."""

    return service.create_chat(payload)


@router.get("/list", response_model=list[ChatSummary])
def list_chats(service: ChatServiceDependency) -> list[ChatSummary]:
    """List conversations, most recently updated first."""

    return service.list_chats()


@router.get("/{chat_id}", response_model=ChatDetail)
def get_chat(chat_id: str, service: ChatServiceDependency) -> ChatDetail:
    """Return one conversation and its ordered messages."""

    return service.get_chat(chat_id)


@router.post(
    "/{chat_id}/message",
    response_model=ChatMessageResponse,
    status_code=status.HTTP_201_CREATED,
)
def add_message(
    chat_id: str,
    payload: ChatMessageRequest,
    service: ChatServiceDependency,
) -> ChatMessageResponse:
    """Store a user message and the Phase 1 placeholder assistant reply."""

    return service.add_message(chat_id, payload)
