"""End-to-end API tests using an isolated persistent ChromaDB."""

from pathlib import Path

from fastapi.testclient import TestClient

from backend.config import Settings
from backend.main import create_app


def build_client(database_path: Path) -> TestClient:
    settings = Settings(chroma_path=database_path)
    return TestClient(create_app(settings))


def test_chat_lifecycle_is_persisted(tmp_path: Path) -> None:
    with build_client(tmp_path / "chroma") as client:
        create_response = client.post("/chat/create", json={})
        assert create_response.status_code == 201
        chat = create_response.json()

        message_response = client.post(
            f"/chat/{chat['id']}/message",
            json={"content": "Explain hybrid memory systems"},
        )
        assert message_response.status_code == 201
        message_payload = message_response.json()
        assert message_payload["assistant_message"]["content"] == (
            "Backend connected successfully."
        )
        assert message_payload["user_message"]["role"] == "user"
        assert message_payload["assistant_message"]["role"] == "assistant"

        detail_response = client.get(f"/chat/{chat['id']}")
        assert detail_response.status_code == 200
        detail = detail_response.json()
        assert len(detail["messages"]) == 2
        assert detail["messages"][0]["content"] == "Explain hybrid memory systems"

        list_response = client.get("/chat/list")
        assert list_response.status_code == 200
        assert list_response.json()[0]["id"] == chat["id"]


def test_missing_chat_returns_404(tmp_path: Path) -> None:
    with build_client(tmp_path / "chroma") as client:
        response = client.get("/chat/does-not-exist")
        assert response.status_code == 404
        assert response.json() == {"detail": "Chat not found."}


def test_health_endpoint(tmp_path: Path) -> None:
    with build_client(tmp_path / "chroma") as client:
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json() == {"status": "healthy"}
