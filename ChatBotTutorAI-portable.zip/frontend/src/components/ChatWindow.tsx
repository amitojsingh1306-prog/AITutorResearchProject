import { useEffect, useRef } from "react";

import type { ChatDetail } from "../types/chat";
import { BookIcon, MenuIcon, SparkIcon } from "./Icons";
import { LoadingBubble } from "./LoadingBubble";
import { MessageBubble } from "./MessageBubble";
import { MessageComposer } from "./MessageComposer";

interface ChatWindowProps {
  chat: ChatDetail | null;
  isLoadingChat: boolean;
  isSending: boolean;
  onOpenSidebar: () => void;
  onSend: (content: string) => Promise<void>;
}

export function ChatWindow({
  chat,
  isLoadingChat,
  isSending,
  onOpenSidebar,
  onSend,
}: ChatWindowProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chat?.messages, isSending]);

  return (
    <main className="flex min-w-0 flex-1 flex-col bg-ink-900">
      <header className="flex h-16 shrink-0 items-center gap-3 border-b border-white/[0.06] px-4 sm:px-6">
        <button
          type="button"
          aria-label="Open sidebar"
          className="rounded-lg p-2 text-slate-400 hover:bg-white/5 hover:text-white md:hidden"
          onClick={onOpenSidebar}
        >
          <MenuIcon className="h-5 w-5" />
        </button>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-slate-200">
            {chat?.title ?? "New learning session"}
          </p>
          <p className="text-[11px] text-slate-600">
            Hybrid Memory Tutor · Local workspace
          </p>
        </div>
        <div className="hidden items-center gap-2 rounded-full border border-white/[0.07] bg-white/[0.03] px-3 py-1.5 text-[11px] text-slate-500 sm:flex">
          <span className="h-1.5 w-1.5 rounded-full bg-accent-400" />
          Backend ready
        </div>
      </header>

      <section className="min-h-0 flex-1 overflow-y-auto">
        <div className="mx-auto flex min-h-full w-full max-w-3xl flex-col px-4 py-8 sm:px-6">
          {isLoadingChat ? (
            <div className="grid flex-1 place-items-center">
              <div className="flex items-center gap-3 text-sm text-slate-500">
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-slate-700 border-t-accent-400" />
                Restoring conversation…
              </div>
            </div>
          ) : !chat || chat.messages.length === 0 ? (
            <div className="grid flex-1 place-items-center">
              <div className="max-w-md text-center">
                <div className="relative mx-auto mb-6 grid h-16 w-16 place-items-center rounded-2xl border border-accent-400/20 bg-accent-500/10 text-accent-400 shadow-glow">
                  <BookIcon className="h-7 w-7" />
                  <SparkIcon className="absolute -right-2 -top-2 h-5 w-5 text-accent-400" />
                </div>
                <h1 className="text-2xl font-semibold tracking-tight text-white sm:text-3xl">
                  What would you like to learn?
                </h1>
                <p className="mt-3 text-sm leading-6 text-slate-500">
                  Start a conversation with your local AI tutor. This foundation
                  will grow into a hybrid-memory learning system.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-6 py-2">
              {chat.messages.map((message) => (
                <MessageBubble key={message.id} message={message} />
              ))}
              {isSending && <LoadingBubble />}
            </div>
          )}
          <div ref={bottomRef} />
        </div>
      </section>

      <MessageComposer disabled={isSending} onSend={onSend} />
    </main>
  );
}
