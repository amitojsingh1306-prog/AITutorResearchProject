import type { Message } from "../types/chat";
import { SparkIcon } from "./Icons";

interface MessageBubbleProps {
  message: Message;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isUser = message.role === "user";

  return (
    <div className={`flex gap-3 ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && (
        <div className="mt-1 grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-accent-400/20 bg-accent-500/10 text-accent-400">
          <SparkIcon className="h-4 w-4" />
        </div>
      )}
      <div
        className={`max-w-[82%] rounded-2xl px-4 py-3 text-[15px] leading-7 sm:max-w-[72%] ${
          isUser
            ? "rounded-br-md bg-accent-600 text-white"
            : "rounded-bl-md border border-white/[0.07] bg-ink-800 text-slate-200"
        }`}
      >
        <p className="whitespace-pre-wrap break-words">{message.content}</p>
        <p
          className={`mt-1.5 text-[10px] ${
            isUser ? "text-emerald-100/60" : "text-slate-600"
          }`}
        >
          {new Date(message.timestamp).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </p>
      </div>
    </div>
  );
}
