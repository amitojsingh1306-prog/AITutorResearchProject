import { useCallback, useEffect, useState } from "react";

import { chatApi } from "./api/chatApi";
import { ChatSidebar } from "./components/ChatSidebar";
import { ChatWindow } from "./components/ChatWindow";
import type { ChatDetail, ChatSummary } from "./types/chat";

export default function App() {
  const [chats, setChats] = useState<ChatSummary[]>([]);
  const [activeChat, setActiveChat] = useState<ChatDetail | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [isLoadingChat, setIsLoadingChat] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const openChat = useCallback(async (chatId: string) => {
    setIsLoadingChat(true);
    setError(null);
    try {
      const chat = await chatApi.get(chatId);
      setActiveChat(chat);
      setIsSidebarOpen(false);
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? requestError.message
          : "Could not restore the conversation.",
      );
    } finally {
      setIsLoadingChat(false);
    }
  }, []);

  useEffect(() => {
    async function loadChats() {
      setIsLoadingChat(true);
      try {
        const previousChats = await chatApi.list();
        setChats(previousChats);
        if (previousChats.length > 0) {
          await openChat(previousChats[0].id);
        }
      } catch {
        setError("Cannot reach the backend. Start FastAPI on port 8000.");
      } finally {
        setIsLoadingChat(false);
      }
    }
    void loadChats();
  }, [openChat]);

  async function createChat(): Promise<ChatDetail | null> {
    setIsCreating(true);
    setError(null);
    try {
      const created = await chatApi.create();
      setChats((current) => [created, ...current]);
      const detail: ChatDetail = { ...created, messages: [] };
      setActiveChat(detail);
      setIsSidebarOpen(false);
      return detail;
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? requestError.message
          : "Could not create a conversation.",
      );
      return null;
    } finally {
      setIsCreating(false);
      setIsLoadingChat(false);
    }
  }

  async function sendMessage(content: string) {
    setIsSending(true);
    setError(null);
    try {
      const targetChat = activeChat ?? (await createChat());
      if (!targetChat) return;

      const response = await chatApi.sendMessage(targetChat.id, content);
      setActiveChat((current) => ({
        ...(current ?? targetChat),
        ...response.chat,
        messages: [
          ...(current?.messages ?? targetChat.messages),
          response.user_message,
          response.assistant_message,
        ],
      }));
      setChats((current) => [
        response.chat,
        ...current.filter((chat) => chat.id !== response.chat.id),
      ]);
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? requestError.message
          : "The message could not be sent.",
      );
    } finally {
      setIsSending(false);
    }
  }

  return (
    <div className="flex h-dvh overflow-hidden bg-ink-900 text-slate-100">
      <ChatSidebar
        chats={chats}
        selectedChatId={activeChat?.id ?? null}
        isOpen={isSidebarOpen}
        isCreating={isCreating}
        onClose={() => setIsSidebarOpen(false)}
        onCreateChat={() => void createChat()}
        onSelectChat={(chatId) => void openChat(chatId)}
      />
      <div className="relative flex min-w-0 flex-1">
        {error && (
          <div
            role="alert"
            className="absolute left-1/2 top-4 z-20 w-[calc(100%-2rem)] max-w-xl -translate-x-1/2 rounded-xl border border-red-400/20 bg-red-950/90 px-4 py-3 text-center text-sm text-red-200 shadow-xl backdrop-blur"
          >
            {error}
          </div>
        )}
        <ChatWindow
          chat={activeChat}
          isLoadingChat={isLoadingChat}
          isSending={isSending}
          onOpenSidebar={() => setIsSidebarOpen(true)}
          onSend={sendMessage}
        />
      </div>
    </div>
  );
}
