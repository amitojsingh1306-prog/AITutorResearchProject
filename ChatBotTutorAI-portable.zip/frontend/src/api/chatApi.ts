import type {
  ChatDetail,
  ChatMessageResponse,
  ChatSummary,
} from "../types/chat";

const API_URL = (import.meta.env.VITE_API_URL ?? "http://localhost:8000").replace(
  /\/$/,
  "",
);

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options?.headers,
    },
  });

  if (!response.ok) {
    const body = (await response.json().catch(() => null)) as {
      detail?: string;
    } | null;
    throw new Error(body?.detail ?? `Request failed with status ${response.status}.`);
  }

  return response.json() as Promise<T>;
}

export const chatApi = {
  list: () => request<ChatSummary[]>("/chat/list"),

  create: () =>
    request<ChatSummary>("/chat/create", {
      method: "POST",
      body: JSON.stringify({}),
    }),

  get: (chatId: string) => request<ChatDetail>(`/chat/${chatId}`),

  sendMessage: (chatId: string, content: string) =>
    request<ChatMessageResponse>(`/chat/${chatId}/message`, {
      method: "POST",
      body: JSON.stringify({ content }),
    }),
};
